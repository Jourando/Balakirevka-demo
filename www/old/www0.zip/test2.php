<?php
echo "<a href=\"http://test2.ru/actlog.php?act=ACTL&u=Joue&doc=http://test2.ru&obj=link2&e=OnClick&t=HttpCall&code=Success\">write an action</a><br>";
echo "<a href=\"http://test2.ru/actlog.php?act=VARL&u=Joue&f=selftest&v1=logged&v2=true&r=0.2657893\">write a var</a><br>";
?>